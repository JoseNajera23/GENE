﻿using ClienteWCF.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClienteWCF
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //2026-01-22  JJBN
            //Creacion de instancia del cliente
            Service1Client cliente = new Service1Client();

            try
            {
                //LLamar Metodo Hola mundo
                string mensaje = cliente.HolaMundo();
                Console.WriteLine(mensaje);
                Console.WriteLine();

                //llamar al obtenerUusarios
                string[] usuarios = cliente.ObtenerUsuarios();
                Console.WriteLine("Usuario en la base  de datos:");
                foreach (string usuario in usuarios)
                {
                    Console.WriteLine("- " + usuario);
                }
                //cerrar la conexion
                cliente.Close();

            }
            catch (Exception ex)
            {

                Console.WriteLine("Error: " + ex.Message);
            }
            Console.ReadKey();
        }
    }
}
