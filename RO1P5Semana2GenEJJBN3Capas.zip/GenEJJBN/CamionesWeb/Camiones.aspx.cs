﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocios;
using CapaEntidades;

namespace CamionesWeb
{
    public partial class Camiones : System.Web.UI.Page
    {
        private N_Camion objNegocio = new N_Camion();

        // Propiedades para mantener el estado
        private int idCamionSeleccionado
        {
            get { return ViewState["idCamionSeleccionado"] != null ? (int)ViewState["idCamionSeleccionado"] : 0; }
            set { ViewState["idCamionSeleccionado"] = value; }
        }

        private bool esNuevo
        {
            get { return ViewState["esNuevo"] != null ? (bool)ViewState["esNuevo"] : false; }
            set { ViewState["esNuevo"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CargarCamiones();
                BloquearControles();
            }
        }

        #region Métodos de Carga y Control

        private void CargarCamiones()
        {
            try
            {
                bool? disponibilidad = null;

                // Determinar filtro
                if (ddlFiltro.SelectedValue == "1")
                    disponibilidad = true;
                else if (ddlFiltro.SelectedValue == "2")
                    disponibilidad = false;

                List<E_Camion> lista = objNegocio.ListarCamiones(disponibilidad);

                // Aplicar búsqueda por texto
                if (!string.IsNullOrWhiteSpace(txtBuscar.Text))
                {
                    string busqueda = txtBuscar.Text.Trim().ToUpper();
                    lista = lista.Where(c =>
                        c.Matricula.ToUpper().Contains(busqueda) ||
                        c.Marca.ToUpper().Contains(busqueda) ||
                        c.TipoCamion.ToUpper().Contains(busqueda)
                    ).ToList();
                }

                gvCamiones.DataSource = lista;
                gvCamiones.DataBind();

                if (lista.Count == 0)
                    MostrarMensaje("No hay camiones registrados con los filtros aplicados", "info");
            }
            catch (Exception ex)
            {
                MostrarMensaje("Error al cargar camiones: " + ex.Message, "danger");
            }
        }

        private void BloquearControles()
        {
            txtMatricula.Enabled = false;
            txtTipoCamion.Enabled = false;
            txtMarca.Enabled = false;
            txtModelo.Enabled = false;
            txtCapacidad.Enabled = false;
            txtKilometraje.Enabled = false;
            txtUrlFoto.Enabled = false;
            chkDisponibilidad.Enabled = false;

            btnGuardar.Enabled = false;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
            btnCancelar.Enabled = false;
        }

        private void DesbloquearControles()
        {
            txtMatricula.Enabled = true;
            txtTipoCamion.Enabled = true;
            txtMarca.Enabled = true;
            txtModelo.Enabled = true;
            txtCapacidad.Enabled = true;
            txtKilometraje.Enabled = true;
            txtUrlFoto.Enabled = true;
            chkDisponibilidad.Enabled = true;

            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
        }

        private void LimpiarControles()
        {
            idCamionSeleccionado = 0;
            txtMatricula.Text = string.Empty;
            txtTipoCamion.Text = string.Empty;
            txtMarca.Text = string.Empty;
            txtModelo.Text = DateTime.Now.Year.ToString();
            txtCapacidad.Text = string.Empty;
            txtKilometraje.Text = "0";
            txtUrlFoto.Text = string.Empty;
            chkDisponibilidad.Checked = true;
            pnlMensaje.Visible = false;
        }

        private void MostrarMensaje(string mensaje, string tipo)
        {
            lblMensaje.Text = mensaje;
            divMensaje.Attributes["class"] = "info-mensaje " + tipo;
            pnlMensaje.Visible = true;
        }

        #endregion

        #region Eventos de Botones

        protected void btnNuevo_Click(object sender, EventArgs e)
        {
            esNuevo = true;
            LimpiarControles();
            DesbloquearControles();

            btnNuevo.Enabled = false;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;

            MostrarMensaje("Ingrese los datos del nuevo camión", "info");
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                // Validaciones básicas
                if (string.IsNullOrWhiteSpace(txtMatricula.Text))
                {
                    MostrarMensaje("La matrícula es obligatoria", "warning");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtTipoCamion.Text))
                {
                    MostrarMensaje("El tipo de camión es obligatorio", "warning");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtMarca.Text))
                {
                    MostrarMensaje("La marca es obligatoria", "warning");
                    return;
                }

                int modelo;
                if (!int.TryParse(txtModelo.Text, out modelo))
                {
                    MostrarMensaje("El modelo debe ser un año válido", "warning");
                    return;
                }

                int capacidad;
                if (!int.TryParse(txtCapacidad.Text, out capacidad))
                {
                    MostrarMensaje("La capacidad debe ser un número válido", "warning");
                    return;
                }

                double kilometraje;
                if (!double.TryParse(txtKilometraje.Text, out kilometraje))
                {
                    MostrarMensaje("El kilometraje debe ser un número válido", "warning");
                    return;
                }

                // Crear objeto E_Camion
                E_Camion camion = new E_Camion
                {
                    IdCamion = idCamionSeleccionado,
                    Matricula = txtMatricula.Text.Trim().ToUpper(),
                    TipoCamion = txtTipoCamion.Text.Trim(),
                    Marca = txtMarca.Text.Trim(),
                    Modelo = modelo,
                    Capacidad = capacidad,
                    Kilometraje = kilometraje,
                    UrlFoto = txtUrlFoto.Text.Trim(),
                    Disponibilidad = chkDisponibilidad.Checked,
                    FechaRegistro = DateTime.Now
                };

                // Guardar o actualizar
                string resultado = esNuevo ?
                    objNegocio.InsertaCamion(camion) :
                    objNegocio.ActualizarCamion(camion);

                if (resultado == "Ok" || resultado == "OK")
                {
                    MostrarMensaje(
                        esNuevo ? " Camión registrado exitosamente" : " Camión actualizado exitosamente",
                        "success"
                    );

                    CargarCamiones();
                    LimpiarControles();
                    BloquearControles();
                    btnNuevo.Enabled = true;
                    esNuevo = false;
                }
                else
                {
                    MostrarMensaje(resultado, "danger");
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje("Error al guardar: " + ex.Message, "danger");
            }
        }

        protected void btnModificar_Click(object sender, EventArgs e)
        {
            if (idCamionSeleccionado == 0)
            {
                MostrarMensaje(" Debe seleccionar un camión de la lista", "warning");
                return;
            }

            esNuevo = false;
            DesbloquearControles();
            txtMatricula.Enabled = false; // Bloquear matrícula en edición

            btnNuevo.Enabled = false;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;

            MostrarMensaje("Modifique los datos y presione Guardar", "info");
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idCamionSeleccionado == 0)
            {
                MostrarMensaje(" Debe seleccionar un camión de la lista", "warning");
                return;
            }

            try
            {
                string resultado = objNegocio.EliminarCamion(idCamionSeleccionado);

                if (resultado == "Ok" || resultado == "OK")
                {
                    MostrarMensaje(" Camión eliminado exitosamente", "success");
                    CargarCamiones();
                    LimpiarControles();
                    BloquearControles();
                    btnNuevo.Enabled = true;
                }
                else
                {
                    MostrarMensaje(resultado, "danger");
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje("Error al eliminar: " + ex.Message, "danger");
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            LimpiarControles();
            BloquearControles();
            btnNuevo.Enabled = true;
            esNuevo = false;
            MostrarMensaje("Operación cancelada", "info");
        }

        #endregion

        #region Eventos GridView y Filtros

        protected void gvCamiones_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Seleccionar")
            {
                try
                {
                    int rowIndex = Convert.ToInt32(e.CommandArgument);
                    GridViewRow row = gvCamiones.Rows[rowIndex];

                    idCamionSeleccionado = Convert.ToInt32(row.Cells[0].Text);
                    txtMatricula.Text = row.Cells[1].Text;
                    txtTipoCamion.Text = row.Cells[2].Text;
                    txtMarca.Text = row.Cells[3].Text;
                    txtModelo.Text = row.Cells[4].Text;
                    txtCapacidad.Text = row.Cells[5].Text.Replace(",", ""); // Eliminar formato de miles
                    txtKilometraje.Text = row.Cells[6].Text;

                    // Obtener disponibilidad del badge
                    var disponibilidadCell = row.Cells[7];
                    chkDisponibilidad.Checked = disponibilidadCell.Text.Contains("Disponible") &&
                                                !disponibilidadCell.Text.Contains("No Disponible");

                    // Cargar datos completos del camión
                    E_Camion camion = objNegocio.ObtenerCamionPorId(idCamionSeleccionado);
                    if (camion != null)
                    {
                        txtUrlFoto.Text = camion.UrlFoto ?? "";
                    }

                    btnModificar.Enabled = true;
                    btnEliminar.Enabled = true;

                    MostrarMensaje(" Camión seleccionado. Puede Modificar o Eliminar.", "info");
                }
                catch (Exception ex)
                {
                    MostrarMensaje("Error al seleccionar: " + ex.Message, "danger");
                }
            }
        }

        protected void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            CargarCamiones();
        }

        protected void ddlFiltro_SelectedIndexChanged(object sender, EventArgs e)
        {
            CargarCamiones();
        }

        #endregion
    }
}