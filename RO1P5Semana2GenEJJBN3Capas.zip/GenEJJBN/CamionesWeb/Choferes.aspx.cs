﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaNegocios;
using CapaEntidades;

namespace ChoferesWeb
{
    public partial class Choferes : System.Web.UI.Page
    {
        private N_Chofer objtNegocio = new N_Chofer();

        // Propiedades para mantener el estado
        private int idChoferSeleccionado
        {
            get { return ViewState["idChoferSeleccionado"] != null ? (int)ViewState["idChoferSeleccionado"] : 0; }
            set { ViewState["idChoferSeleccionado"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CargarChoferes();
                ConfigurarControlesIniciales();
            }
        }

        #region Métodos de Carga y Control

        private void CargarChoferes()
        {
            try
            {
                bool? disponibilidad = null;

                // Determinar filtro
                if (ddlFiltro.SelectedValue == "1")
                    disponibilidad = true;
                else if (ddlFiltro.SelectedValue == "2")
                    disponibilidad = false;

                List<E_Chofer> lista = objtNegocio.ListarChoferes(disponibilidad);

                // Aplicar búsqueda por texto
                if (!string.IsNullOrWhiteSpace(txtBuscar.Text))
                {
                    string busqueda = txtBuscar.Text.Trim().ToUpper();
                    lista = lista.Where(c =>
                        c.Nombre.ToUpper().Contains(busqueda) ||
                        c.ApPaterno.ToUpper().Contains(busqueda) ||
                        (c.ApMaterno != null && c.ApMaterno.ToUpper().Contains(busqueda)) ||
                        c.Telefono.Contains(busqueda) ||
                        c.Licencia.ToUpper().Contains(busqueda)
                    ).ToList();
                }

                gvChoferes.DataSource = lista;
                gvChoferes.DataBind();

                if (lista.Count == 0)
                    MostrarMensaje(" No hay choferes registrados con los filtros aplicados", "info");
            }
            catch (Exception ex)
            {
                MostrarMensaje(" Error al cargar choferes: " + ex.Message, "danger");
            }
        }

        private void ConfigurarControlesIniciales()
        {
            // Los campos siempre están habilitados para nuevo registro
            txtNombre.Enabled = true;
            txtApPaterno.Enabled = true;
            txtApMaterno.Enabled = true;
            txtTelefono.Enabled = true;
            txtFechaNacimiento.Enabled = true;
            txtLicencia.Enabled = true;
            txtUrlFoto.Enabled = true;
            chkDisponibilidad.Enabled = true;

            // Solo Guardar y Cancelar habilitados inicialmente
            btnGuardar.Enabled = true;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
            btnCancelar.Enabled = true;

            LimpiarCampos();
            MostrarMensaje("Complete el formulario para registrar un nuevo chofer", "info");
        }

        private void LimpiarCampos()
        {
            idChoferSeleccionado = 0;
            txtNombre.Text = string.Empty;
            txtApPaterno.Text = string.Empty;
            txtApMaterno.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            // Establecer una fecha por defecto válida (25 años atrás)
            txtFechaNacimiento.Text = DateTime.Now.AddYears(-25).ToString("yyyy-MM-dd");
            txtLicencia.Text = string.Empty;
            txtUrlFoto.Text = string.Empty;
            chkDisponibilidad.Checked = true;
        }

        private void MostrarMensaje(string mensaje, string tipo)
        {
            try
            {
                lblMensaje.Text = mensaje;
                divMensaje.Attributes["class"] = "mensaje " + tipo;
                pnlMensaje.Visible = true;

                // Actualizar el UpdatePanel si existe
                UpdatePanel upMensajes = (UpdatePanel)form1.FindControl("upMensajes");
                if (upMensajes != null)
                {
                    upMensajes.Update();
                }
            }
            catch (Exception ex)
            {
                lblMensaje.Text = mensaje;
                pnlMensaje.Visible = true;
            }
        }

        #endregion

        #region Eventos de Botones

        protected void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();

            // Habilitar solo Guardar y Cancelar
            btnGuardar.Enabled = true;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
            btnCancelar.Enabled = true;

            MostrarMensaje("Ingrese los datos del nuevo chofer", "info");
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                // Validaciones básicas
                if (string.IsNullOrWhiteSpace(txtNombre.Text))
                {
                    MostrarMensaje(" El nombre es obligatorio", "warning");
                    txtNombre.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtApPaterno.Text))
                {
                    MostrarMensaje("El apellido paterno es obligatorio", "warning");
                    txtApPaterno.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtTelefono.Text))
                {
                    MostrarMensaje("El teléfono es obligatorio", "warning");
                    txtTelefono.Focus();
                    return;
                }

                if (txtTelefono.Text.Trim().Length != 10)
                {
                    MostrarMensaje("El teléfono debe tener exactamente 10 dígitos", "warning");
                    txtTelefono.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtLicencia.Text))
                {
                    MostrarMensaje("La licencia es obligatoria", "warning");
                    txtLicencia.Focus();
                    return;
                }

                // VALIDACIÓN CRÍTICA DE FECHA
                if (string.IsNullOrWhiteSpace(txtFechaNacimiento.Text))
                {
                    MostrarMensaje("La fecha de nacimiento es obligatoria", "warning");
                    txtFechaNacimiento.Focus();
                    return;
                }

                DateTime fechaNacimiento;
                if (!DateTime.TryParse(txtFechaNacimiento.Text, out fechaNacimiento))
                {
                    MostrarMensaje("La fecha de nacimiento es inválida", "warning");
                    txtFechaNacimiento.Focus();
                    return;
                }

                // Validar que la fecha esté en rango válido de SQL Server
                if (fechaNacimiento < new DateTime(1753, 1, 1) || fechaNacimiento > new DateTime(9999, 12, 31))
                {
                    MostrarMensaje("La fecha de nacimiento debe estar entre 01/01/1753 y 31/12/9999", "warning");
                    txtFechaNacimiento.Focus();
                    return;
                }

                // Validar que sea una fecha lógica (no futura, no muy antigua)
                if (fechaNacimiento > DateTime.Now)
                {
                    MostrarMensaje("La fecha de nacimiento no puede ser futura", "warning");
                    txtFechaNacimiento.Focus();
                    return;
                }

                if (fechaNacimiento < DateTime.Now.AddYears(-100))
                {
                    MostrarMensaje("La fecha de nacimiento no puede ser mayor a 100 años", "warning");
                    txtFechaNacimiento.Focus();
                    return;
                }

                // Validar edad mínima
                int edad = DateTime.Now.Year - fechaNacimiento.Year;
                if (fechaNacimiento > DateTime.Now.AddYears(-edad)) edad--;

                if (edad < 18)
                {
                    MostrarMensaje("El chofer debe ser mayor de edad (mínimo 18 años)", "warning");
                    txtFechaNacimiento.Focus();
                    return;
                }

                // Crear objeto E_Chofer
                E_Chofer chofer = new E_Chofer
                {
                    IdChofer = idChoferSeleccionado,
                    Nombre = txtNombre.Text.Trim(),
                    ApPaterno = txtApPaterno.Text.Trim(),
                    ApMaterno = string.IsNullOrWhiteSpace(txtApMaterno.Text) ? "" : txtApMaterno.Text.Trim(),
                    Telefono = txtTelefono.Text.Trim(),
                    FechaNacimiento = fechaNacimiento,
                    Licencia = txtLicencia.Text.Trim().ToUpper(),
                    UrlFoto = string.IsNullOrWhiteSpace(txtUrlFoto.Text) ? "" : txtUrlFoto.Text.Trim(),
                    Disponibilidad = chkDisponibilidad.Checked
                };

                // 🐛 DEBUG: Verificar valores antes de guardar (TEMPORAL - ELIMINAR DESPUÉS)
                System.Diagnostics.Debug.WriteLine("=== VALORES DEL CHOFER ===");
                System.Diagnostics.Debug.WriteLine($"Nombre: {chofer.Nombre}");
                System.Diagnostics.Debug.WriteLine($"ApPaterno: {chofer.ApPaterno}");
                System.Diagnostics.Debug.WriteLine($"ApMaterno: {chofer.ApMaterno}");
                System.Diagnostics.Debug.WriteLine($"Telefono: {chofer.Telefono}");
                System.Diagnostics.Debug.WriteLine($"FechaNacimiento: {chofer.FechaNacimiento}");
                System.Diagnostics.Debug.WriteLine($"Licencia: {chofer.Licencia}");
                System.Diagnostics.Debug.WriteLine($"UrlFoto: {chofer.UrlFoto}");
                System.Diagnostics.Debug.WriteLine($"Disponibilidad: {chofer.Disponibilidad}");
                System.Diagnostics.Debug.WriteLine("========================");

                // Guardar o actualizar
                string resultado;
                bool esActualizacion = idChoferSeleccionado > 0;

                if (esActualizacion)
                {
                    resultado = objtNegocio.ActualizarChofer(chofer);
                }
                else
                {
                    resultado = objtNegocio.InsertarChofer(chofer);
                }

                if (resultado == "OK")
                {
                    string mensajeExito = esActualizacion ?
                        "Chofer actualizado exitosamente" :
                        "Chofer registrado exitosamente";

                    // Limpiar y recargar
                    LimpiarCampos();
                    CargarChoferes();

                    // Restaurar botones
                    btnGuardar.Enabled = true;
                    btnModificar.Enabled = false;
                    btnEliminar.Enabled = false;

                    // Mostrar mensaje de éxito
                    MostrarMensaje(mensajeExito, "success");
                }
                else
                {
                    MostrarMensaje("x" + resultado, "danger");
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje("Error al guardar: " + ex.Message, "danger");
            }
        }

        protected void btnModificar_Click(object sender, EventArgs e)
        {
            if (idChoferSeleccionado == 0)
            {
                MostrarMensaje("Debe seleccionar un chofer de la lista primero", "warning");
                return;
            }

            MostrarMensaje("Modifique los datos y presione 'Guardar'", "info");
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idChoferSeleccionado == 0)
            {
                MostrarMensaje("Debe seleccionar un chofer de la lista primero", "warning");
                return;
            }

            try
            {
                string resultado = objtNegocio.EliminarChofer(idChoferSeleccionado);

                if (resultado == "OK")
                {
                    MostrarMensaje("Chofer eliminado exitosamente", "success");
                    LimpiarCampos();
                    CargarChoferes();

                    btnModificar.Enabled = false;
                    btnEliminar.Enabled = false;
                }
                else
                {
                    MostrarMensaje("x" + resultado, "danger");
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje("Error al eliminar: " + ex.Message, "danger");
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            btnGuardar.Enabled = true;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
            MostrarMensaje("Operación cancelada. Formulario limpio", "info");
        }

        #endregion

        #region Eventos GridView y Filtros

        protected void gvChoferes_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Seleccionar")
            {
                try
                {
                    int rowIndex = Convert.ToInt32(e.CommandArgument);
                    GridViewRow row = gvChoferes.Rows[rowIndex];

                    idChoferSeleccionado = Convert.ToInt32(row.Cells[0].Text);
                    txtNombre.Text = row.Cells[1].Text;
                    txtApPaterno.Text = row.Cells[2].Text;
                    txtApMaterno.Text = row.Cells[3].Text == "&nbsp;" ? "" : row.Cells[3].Text;
                    txtTelefono.Text = row.Cells[4].Text;

                    // Parsear fecha
                    string fechaTexto = row.Cells[5].Text;
                    DateTime fecha;
                    if (DateTime.TryParse(fechaTexto, out fecha))
                    {
                        txtFechaNacimiento.Text = fecha.ToString("yyyy-MM-dd");
                    }

                    txtLicencia.Text = row.Cells[6].Text;

                    // Obtener disponibilidad
                    var disponibilidadCell = row.Cells[7];
                    chkDisponibilidad.Checked = disponibilidadCell.Text.Contains("Disponible") &&
                                                !disponibilidadCell.Text.Contains("No Disponible");

                    // Cargar URL de foto
                    List<E_Chofer> lista = objtNegocio.ListarChoferes();
                    E_Chofer chofer = lista.FirstOrDefault(c => c.IdChofer == idChoferSeleccionado);

                    if (chofer != null)
                    {
                        txtUrlFoto.Text = chofer.UrlFoto ?? "";
                    }

                    // Habilitar botones de Modificar y Eliminar
                    btnModificar.Enabled = true;
                    btnEliminar.Enabled = true;

                    MostrarMensaje("Chofer seleccionado. Puede Modificar o Eliminar", "info");
                }
                catch (Exception ex)
                {
                    MostrarMensaje("Error al seleccionar: " + ex.Message, "danger");
                }
            }
        }

        protected void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            CargarChoferes();
        }

        protected void ddlFiltro_SelectedIndexChanged(object sender, EventArgs e)
        {
            CargarChoferes();
        }

        #endregion
    }
}