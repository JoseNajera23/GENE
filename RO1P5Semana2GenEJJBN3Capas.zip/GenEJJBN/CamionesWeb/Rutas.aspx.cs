﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using CapaNegocios;
using CapaEntidades;
using CapaDatos;

namespace RutasWeb
{
    public partial class Rutas : System.Web.UI.Page
    {
        private N_Ruta objNegocio = new N_Ruta();

        private int idRutaSeleccionada
        {
            get { return ViewState["idRuta"] != null ? (int)ViewState["idRuta"] : 0; }
            set { ViewState["idRuta"] = value; }
        }

        private bool esNuevo
        {
            get { return ViewState["esNuevo"] != null ? (bool)ViewState["esNuevo"] : false; }
            set { ViewState["esNuevo"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CargarRutas();
                BloquearControles();
            }
        }


        private void CargarRutas()
        {
            try
            {
                List<E_Ruta> lista = objNegocio.ListarRutas() ?? new List<E_Ruta>();

                // Aplicar filtro
                if (ddlFiltro.SelectedValue == "1")
                    lista = lista.FindAll(r => r.ATiempo == true);
                else if (ddlFiltro.SelectedValue == "2")
                    lista = lista.FindAll(r => r.ATiempo == false);

                gvRutas.DataSource = lista;
                gvRutas.DataBind();
            }
            catch (Exception ex)
            {
                Mensaje("Error: " + ex.Message, "danger");
            }
        }

        private void BloquearControles()
        {
            txtIdChofer.Enabled = false;
            txtIdCamion.Enabled = false;
            txtOrigen.Enabled = false;
            txtDestino.Enabled = false;
            txtFechaSalida.Enabled = false;
            txtFechaLlegada.Enabled = false;
            txtDistancia.Enabled = false;
            chkATiempo.Enabled = false;

            btnGuardar.Enabled = false;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
            btnCancelar.Enabled = false;
        }

        private void DesbloquearControles()
        {
            txtIdChofer.Enabled = true;
            txtIdCamion.Enabled = true;
            txtOrigen.Enabled = true;
            txtDestino.Enabled = true;
            txtFechaSalida.Enabled = true;
            txtFechaLlegada.Enabled = true;
            txtDistancia.Enabled = true;
            chkATiempo.Enabled = true;

            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
        }

        private void Limpiar()
        {
            idRutaSeleccionada = 0;
            txtIdChofer.Text = "";
            txtIdCamion.Text = "";
            txtOrigen.Text = "";
            txtDestino.Text = "";
            txtFechaSalida.Text = "";
            txtFechaLlegada.Text = "";
            txtDistancia.Text = "0";
            chkATiempo.Checked = true;
            pnlMensaje.Visible = false;
        }

        private void Mensaje(string texto, string tipo)
        {
            lblMensaje.Text = texto;
            pnlMensaje.Visible = true;
            pnlMensaje.CssClass = "mensaje " + tipo;
        }

        protected void btnNuevo_Click(object sender, EventArgs e)
        {
            esNuevo = true;
            Limpiar();
            DesbloquearControles();
            btnNuevo.Enabled = false;
            Mensaje("Ingrese los datos de la nueva ruta", "info");
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                // DEBUGGING - Ver qué valores se están enviando
                System.Diagnostics.Debug.WriteLine($"Chofer: {txtIdChofer.Text}");
                System.Diagnostics.Debug.WriteLine($"Camion: {txtIdCamion.Text}");
                System.Diagnostics.Debug.WriteLine($"Origen: {txtOrigen.Text}");
                int idChofer, idCamion;
                double distancia;

                if (!int.TryParse(txtIdChofer.Text, out idChofer))
                {
                    Mensaje("ID Chofer inválido", "warning");
                    return;
                }

                if (!int.TryParse(txtIdCamion.Text, out idCamion))
                {
                    Mensaje("ID Camión inválido", "warning");
                    return;
                }

                if (!double.TryParse(txtDistancia.Text, out distancia))
                {
                    Mensaje("Distancia inválida", "warning");
                    return;
                }

                E_Ruta ruta = new E_Ruta
                {
                    IdRutas = idRutaSeleccionada,
                    IdChofer = idChofer,
                    IdCamion = idCamion,
                    Origen = txtOrigen.Text.Trim(),
                    Destino = txtDestino.Text.Trim(),
                    FechaSalida = DateTime.Parse(txtFechaSalida.Text),
                    FechaLlegada = DateTime.Parse(txtFechaLlegada.Text),
                    ATiempo = chkATiempo.Checked,
                    Distancia = distancia,
                    //FechaRegistro = DateTime.Now
                };

                string resultado = esNuevo ? objNegocio.InsertarRuta(ruta) : objNegocio.Actualizar(ruta);

                if (resultado == "Ok")
                {
                    Mensaje(esNuevo ? "Ruta guardada" : "Ruta actualizada", "success");
                    CargarRutas();
                    Limpiar();
                    BloquearControles();
                    btnNuevo.Enabled = true;
                }
                else
                {
                    Mensaje(resultado, "danger");
                }
            }
            catch (Exception ex)
            {
                Mensaje("Error: " + ex.Message, "danger");
            }
        }

        protected void btnModificar_Click(object sender, EventArgs e)
        {
            if (idRutaSeleccionada == 0)
            {
                Mensaje("Seleccione una ruta", "warning");
                return;
            }

            esNuevo = false;
            DesbloquearControles();
            btnNuevo.Enabled = false;
            btnModificar.Enabled = false;
            Mensaje("Modifique y presione Guardar", "info");
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idRutaSeleccionada == 0)
            {
                Mensaje("Seleccione una ruta", "warning");
                return;
            }

            try
            {
                string resultado = objNegocio.EliminarRuta(idRutaSeleccionada);
                if (resultado == "Ok")
                {
                    Mensaje("Ruta eliminada", "success");
                    CargarRutas();
                    Limpiar();
                    BloquearControles();
                    btnNuevo.Enabled = true;
                }
                else
                {
                    Mensaje(resultado, "danger");
                }
            }
            catch (Exception ex)
            {
                Mensaje("Error: " + ex.Message, "danger");
            }
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            Limpiar();
            BloquearControles();
            btnNuevo.Enabled = true;
            Mensaje("Operación cancelada", "info");
        }

        protected void gvRutas_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Seleccionar")
            {
                try
                {
                    int index = Convert.ToInt32(e.CommandArgument);
                    GridViewRow row = gvRutas.Rows[index];

                    idRutaSeleccionada = Convert.ToInt32(row.Cells[0].Text);
                    txtIdChofer.Text = row.Cells[1].Text;
                    txtIdCamion.Text = row.Cells[2].Text;
                    txtOrigen.Text = row.Cells[3].Text;
                    txtDestino.Text = row.Cells[4].Text;

                    DateTime.TryParse(row.Cells[5].Text, out DateTime salida);
                    txtFechaSalida.Text = salida.ToString("yyyy-MM-dd");

                    DateTime.TryParse(row.Cells[6].Text, out DateTime llegada);
                    txtFechaLlegada.Text = llegada.ToString("yyyy-MM-dd");

                    chkATiempo.Checked = row.Cells[7].Text.Contains("A Tiempo");

                    // Obtener distancia completa
                    List<E_Ruta> rutas = objNegocio.ListarRutas();
                    E_Ruta ruta = rutas.Find(r => r.IdRutas == idRutaSeleccionada);
                    if (ruta != null)
                        txtDistancia.Text = ruta.Distancia.ToString();

                    btnModificar.Enabled = true;
                    btnEliminar.Enabled = true;
                    Mensaje("Ruta seleccionada", "info");
                }
                catch (Exception ex)
                {
                    Mensaje("Error: " + ex.Message, "danger");
                }
            }
        }

        protected void btnFiltrar_Click(object sender, EventArgs e)
        {
            CargarRutas();
        }

        protected void btnActualizar_Click(object sender, EventArgs e)
        {
            ddlFiltro.SelectedIndex = 0;
            CargarRutas();
        }
    }
}