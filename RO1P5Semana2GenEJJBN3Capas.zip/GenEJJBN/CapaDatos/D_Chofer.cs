﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class D_Chofer
    {
        public List<E_Chofer> ListarChoferes(bool? disponibilidad = null)
        {
            List<E_Chofer> lista = new List<E_Chofer>();

            try
            {
                using (SqlConnection conn = Conexion.ObtenerConexion())
                {
                    SqlCommand cmd = new SqlCommand("Listar_Choferes", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlParameter pDisponibilidad = new SqlParameter("@Disponibilidad", SqlDbType.Bit);
                    pDisponibilidad.Value = disponibilidad.HasValue ? (object)disponibilidad.Value : DBNull.Value;
                    cmd.Parameters.Add(pDisponibilidad);

                    // ❌ ELIMINAR: conn.Open(); (ya está abierta)

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            lista.Add(new E_Chofer
                            {
                                IdChofer = Convert.ToInt32(dr["IdChofer"]),
                                Nombre = dr["Nombre"].ToString(),
                                ApPaterno = dr["ApPaterno"].ToString(),
                                ApMaterno = dr["ApMaterno"] != DBNull.Value ? dr["ApMaterno"].ToString() : "",
                                Telefono = dr["Telefono"].ToString(),
                                FechaNacimiento = Convert.ToDateTime(dr["FechaNacimiento"]),
                                Licencia = dr["Licencia"].ToString(),
                                UrlFoto = dr["UrlFoto"] != DBNull.Value ? dr["UrlFoto"].ToString() : "",
                                Disponibilidad = Convert.ToBoolean(dr["Disponibilidad"])
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al listar choferes: " + ex.Message, ex);
            }

            return lista;
        }
        public bool InsertarChofer(E_Chofer chofer)
        {
            try
            {
                using (SqlConnection conn = Conexion.ObtenerConexion())
                {
                    SqlCommand cmd = new SqlCommand("Insert_Chofer", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@Nombre", SqlDbType.VarChar, 100).Value =
                        string.IsNullOrWhiteSpace(chofer.Nombre) ? "" : chofer.Nombre.Trim();

                    cmd.Parameters.Add("@ApPaterno", SqlDbType.VarChar, 100).Value =
                        string.IsNullOrWhiteSpace(chofer.ApPaterno) ? "" : chofer.ApPaterno.Trim();

                    cmd.Parameters.Add("@Telefono", SqlDbType.VarChar, 15).Value =
                        string.IsNullOrWhiteSpace(chofer.Telefono) ? "" : chofer.Telefono.Trim();

                    cmd.Parameters.Add("@Licencia", SqlDbType.VarChar, 50).Value =
                        string.IsNullOrWhiteSpace(chofer.Licencia) ? "" : chofer.Licencia.Trim();

                    cmd.Parameters.Add("@FechaNacimiento", SqlDbType.Date).Value = chofer.FechaNacimiento;

                    cmd.Parameters.Add("@Disponibilidad", SqlDbType.Bit).Value = chofer.Disponibilidad;

                    cmd.Parameters.Add("@ApMaterno", SqlDbType.VarChar, 100).Value =
                        string.IsNullOrWhiteSpace(chofer.ApMaterno) ? (object)DBNull.Value : chofer.ApMaterno.Trim();

                    cmd.Parameters.Add("@UrlFoto", SqlDbType.VarChar, 255).Value =
                        string.IsNullOrWhiteSpace(chofer.UrlFoto) ? (object)DBNull.Value : chofer.UrlFoto.Trim();

                    // ❌ ELIMINAR: conn.Open(); (ya está abierta)

                    int resultado = cmd.ExecuteNonQuery();
                    return resultado > 0;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception($"Error SQL al insertar chofer: {ex.Message} | Procedimiento: {ex.Procedure} | Número: {ex.Number}", ex);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al insertar chofer: " + ex.Message, ex);
            }
        }

        public bool ActualizarChofer(E_Chofer chofer)
        {
            try
            {
                using (SqlConnection conn = Conexion.ObtenerConexion())
                {
                    SqlCommand cmd = new SqlCommand("Update_Chofer", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@IdChofer", SqlDbType.Int).Value = chofer.IdChofer;
                    cmd.Parameters.Add("@Nombre", SqlDbType.VarChar, 100).Value =
                        string.IsNullOrWhiteSpace(chofer.Nombre) ? (object)DBNull.Value : chofer.Nombre;
                    cmd.Parameters.Add("@ApPaterno", SqlDbType.VarChar, 100).Value =
                        string.IsNullOrWhiteSpace(chofer.ApPaterno) ? (object)DBNull.Value : chofer.ApPaterno;
                    cmd.Parameters.Add("@ApMaterno", SqlDbType.VarChar, 100).Value =
                        string.IsNullOrWhiteSpace(chofer.ApMaterno) ? (object)DBNull.Value : chofer.ApMaterno;
                    cmd.Parameters.Add("@Telefono", SqlDbType.VarChar, 15).Value =
                        string.IsNullOrWhiteSpace(chofer.Telefono) ? (object)DBNull.Value : chofer.Telefono;
                    cmd.Parameters.Add("@FechaNacimiento", SqlDbType.Date).Value = chofer.FechaNacimiento;
                    cmd.Parameters.Add("@Licencia", SqlDbType.VarChar, 50).Value =
                        string.IsNullOrWhiteSpace(chofer.Licencia) ? (object)DBNull.Value : chofer.Licencia;
                    cmd.Parameters.Add("@UrlFoto", SqlDbType.VarChar, 255).Value =
                        string.IsNullOrWhiteSpace(chofer.UrlFoto) ? (object)DBNull.Value : chofer.UrlFoto;
                    cmd.Parameters.Add("@Disponibilidad", SqlDbType.Bit).Value = chofer.Disponibilidad;

                    // ❌ ELIMINAR: conn.Open(); (ya está abierta)

                    int resultado = cmd.ExecuteNonQuery();
                    return resultado > 0;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception("Error SQL al actualizar chofer: " + ex.Message + " | Procedimiento: " + ex.Procedure, ex);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al actualizar chofer: " + ex.Message, ex);
            }
        }

        public bool EliminarChoferes(int idChofer)
        {
            try
            {
                using (SqlConnection conn = Conexion.ObtenerConexion())
                {
                    SqlCommand cmd = new SqlCommand("Delete_Chofer", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@IdChofer", SqlDbType.Int).Value = idChofer;

                    // ❌ ELIMINAR: conn.Open(); (ya está abierta)

                    int resultado = cmd.ExecuteNonQuery();
                    return resultado > 0;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al eliminar chofer: " + ex.Message, ex);
            }
        }

        public bool ExisteLicencia(string licencia, int? idChoferExcluir = null)
        {
            try
            {
                using (SqlConnection conn = Conexion.ObtenerConexion())
                {
                    string query = idChoferExcluir.HasValue
                        ? "SELECT COUNT(*) FROM Choferes WHERE Licencia = @Licencia AND IdChofer != @IdChofer"
                        : "SELECT COUNT(*) FROM Choferes WHERE Licencia = @Licencia";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Licencia", licencia);

                    if (idChoferExcluir.HasValue)
                        cmd.Parameters.AddWithValue("@IdChofer", idChoferExcluir.Value);

                    // ❌ ELIMINAR: conn.Open(); (ya está abierta)

                    int resultado = Convert.ToInt32(cmd.ExecuteScalar());
                    return resultado > 0;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al verificar licencia: " + ex.Message, ex);
            }
        }

    }
}