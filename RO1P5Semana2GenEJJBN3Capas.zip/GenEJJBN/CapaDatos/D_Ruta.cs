﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class D_Ruta
    {
        // ========================================
        // LISTAR TODAS LAS RUTAS
        // ========================================
        public List<E_Ruta> ListaRutas()
        {
            List<E_Ruta> lista = new List<E_Ruta>();

            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                SqlCommand cmd = new SqlCommand("Listar_Rutas", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        lista.Add(new E_Ruta
                        {
                            IdRutas = Convert.ToInt32(dr["IdRutas"]),
                            IdChofer = Convert.ToInt32(dr["IdChofer"]),
                            IdCamion = Convert.ToInt32(dr["IdCamion"]),
                            Origen = dr["Origen"].ToString(),
                            Destino = dr["Destino"].ToString(),
                            FechaSalida = Convert.ToDateTime(dr["FechaSalida"]),
                            FechaLlegada = Convert.ToDateTime(dr["FechaLlegada"]),
                            ATiempo = Convert.ToBoolean(dr["ATiempo"]),
                            Distancia = Convert.ToDouble(dr["Distancia"]),
                            FechaRegistro = Convert.ToDateTime(dr["FechaRegistro"])
                        });
                    }
                }
            }

            return lista;
        }

        // ========================================
        // INSERTAR UNA RUTA
        // ========================================
        public bool InsertarRuta(E_Ruta ruta)
        {
            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                try
                {
                    // ✅✅✅ NOMBRE CORRECTO: "Insert_Ruta" (SIN 'S')
                    SqlCommand cmd = new SqlCommand("Insert_Ruta", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@IDChofer", ruta.IdChofer);
                    cmd.Parameters.AddWithValue("@IDCamion", ruta.IdCamion);
                    cmd.Parameters.AddWithValue("@Origen", ruta.Origen);
                    cmd.Parameters.AddWithValue("@Destino", ruta.Destino);
                    cmd.Parameters.AddWithValue("@FechaSalida", ruta.FechaSalida);
                    cmd.Parameters.AddWithValue("@FechaLlegada", ruta.FechaLlegada);
                    cmd.Parameters.AddWithValue("@ATiempo", ruta.ATiempo);
                    cmd.Parameters.AddWithValue("@Distancia", ruta.Distancia);

                    int filasAfectadas = cmd.ExecuteNonQuery();
                    return filasAfectadas > 0;
                }
                catch (SqlException ex)
                {
                    throw new Exception($"Error SQL: {ex.Message} | Procedimiento: {ex.Procedure}");
                }
            }
        }

        // ========================================
        // ACTUALIZAR UNA RUTA
        // ========================================
        public bool ActualizarRuta(E_Ruta ruta)
        {
            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                try
                {
                    // ✅✅✅ NOMBRE CORRECTO: "Update_Ruta" (SIN 'S')
                    SqlCommand cmd = new SqlCommand("Update_Ruta", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@IdRuta", ruta.IdRutas);
                    cmd.Parameters.AddWithValue("@Origen", ruta.Origen);
                    cmd.Parameters.AddWithValue("@Destino", ruta.Destino);
                    cmd.Parameters.AddWithValue("@FechaSalida", ruta.FechaSalida);
                    cmd.Parameters.AddWithValue("@FechaLlegada", ruta.FechaLlegada);
                    cmd.Parameters.AddWithValue("@ATiempo", ruta.ATiempo);
                    cmd.Parameters.AddWithValue("@Distancia", ruta.Distancia);
                    cmd.Parameters.AddWithValue("@IdChofer", ruta.IdChofer);
                    cmd.Parameters.AddWithValue("@IdCamion", ruta.IdCamion);

                    int filasAfectadas = cmd.ExecuteNonQuery();
                    return filasAfectadas > 0;
                }
                catch (SqlException ex)
                {
                    throw new Exception($"Error SQL: {ex.Message} | Procedimiento: {ex.Procedure}");
                }
            }
        }

        // ========================================
        // ELIMINAR UNA RUTA
        // ========================================
        public bool EliminarRutas(int idRuta)
        {
            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                try
                {
                    // ✅✅✅ NOMBRE CORRECTO: "Delete_Ruta" (SIN 'S')
                    SqlCommand cmd = new SqlCommand("Delete_Ruta", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@IdRuta", idRuta);

                    int filasAfectadas = cmd.ExecuteNonQuery();
                    return filasAfectadas > 0;
                }
                catch (SqlException ex)
                {
                    throw new Exception($"Error SQL: {ex.Message} | Procedimiento: {ex.Procedure}");
                }
            }
        }
    }
}