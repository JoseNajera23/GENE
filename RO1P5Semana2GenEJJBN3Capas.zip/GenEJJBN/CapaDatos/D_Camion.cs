﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class D_Camion
    {
        public List<E_Camion> ListarCamiones(bool? disponibilidad = null)
        {
            List<E_Camion> lista = new List<E_Camion>();

            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                SqlCommand cmd = new SqlCommand("Listar_Camiones", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                if (disponibilidad.HasValue)
                    cmd.Parameters.AddWithValue("@Disponibilidad", disponibilidad.Value);
                else
                    cmd.Parameters.AddWithValue("@Disponibilidad", DBNull.Value);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    lista.Add(new E_Camion
                    {
                        IdCamion = Convert.ToInt32(dr["IdCamion"]),
                        Matricula = dr["Matricula"].ToString(),
                        TipoCamion = dr["TipoCamion"].ToString(),
                        Modelo = Convert.ToInt32(dr["Modelo"]),
                        Marca = dr["Marca"].ToString(),
                        Capacidad = Convert.ToInt32(dr["Capacidad"]),
                        Kilometraje = Convert.ToDouble(dr["Kilometraje"]),
                        Disponibilidad = Convert.ToBoolean(dr["Disponibilidad"]),
                        UrlFoto = dr["UrlFoto"] == DBNull.Value ? "" : dr["UrlFoto"].ToString(),
                        FechaRegistro = Convert.ToDateTime(dr["FechaRegistro"])
                    });
                }
            }
            return lista;
        }


        public bool InsertarCamion(E_Camion camion)
        {
            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                SqlCommand cmd = new SqlCommand("Insert_Camion", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Matricula", camion.Matricula);
                cmd.Parameters.AddWithValue("@TipoCamion", camion.TipoCamion);
                cmd.Parameters.AddWithValue("@Modelo", camion.Modelo);
                cmd.Parameters.AddWithValue("@Marca", camion.Marca);
                cmd.Parameters.AddWithValue("@Capacidad", camion.Capacidad);
                cmd.Parameters.AddWithValue("@Kilometraje", camion.Kilometraje);
                cmd.Parameters.AddWithValue("@UrlFoto",
                    string.IsNullOrEmpty(camion.UrlFoto) ? (object)DBNull.Value : camion.UrlFoto);

                return cmd.ExecuteNonQuery() > 0;
            }
        }




        //Eliminar camion
        public bool EliminarCamion(int idCamion) {
            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                SqlCommand cmd = new SqlCommand("Delete_Camion", conn);
                cmd.CommandType= CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@IdCamion", idCamion);
                return cmd.ExecuteNonQuery() >0;
            }
        }

        public bool ExisteMatricula(string matricula)
        {
            using(SqlConnection conn= Conexion.ObtenerConexion())
            {
                SqlCommand cmd = new SqlCommand("Existe_Matricula",conn);
                cmd.CommandType= CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Matricula", matricula);

                int resultado = Convert.ToInt32(cmd.ExecuteScalar());
                return resultado > 0;
            }
        }

        //Obtener camion por id
        public E_Camion ObtenerCamionPorID(int idCamion)
        {
            using(SqlConnection cnn = Conexion.ObtenerConexion())
            {
                SqlCommand cmd = new SqlCommand("Obtener_Camion_PoID", cnn);
                cmd.CommandType= CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@IdCamion", idCamion);
                SqlDataReader rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    return new E_Camion
                    {
                        IdCamion = Convert.ToInt32(rd["IdCamion"]),
                        Matricula = rd["Matricula"].ToString(),
                        TipoCamion = rd["TipoCamion"].ToString(),
                        Modelo = Convert.ToInt32(rd["Modelo"]),
                        Marca = rd["Marca"].ToString(),
                        Capacidad = Convert.ToInt32(rd["Capacidad"]),
                        Kilometraje = Convert.ToDouble(rd["Kilometraje"]),
                        Disponibilidad = Convert.ToBoolean(rd["Disponibilidad"]),
                        UrlFoto = rd["UrlFoto"].ToString(),
                        FechaRegistro = Convert.ToDateTime(rd["FechaRegistro"])
                    };
                }
                return null;
            }
        }

        public bool ActualizarCamion(E_Camion camion)
        {
            using (SqlConnection conn = Conexion.ObtenerConexion())
            {
                SqlCommand cmd = new SqlCommand("Update_Camion", conn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@IdCamion", camion.IdCamion);
                cmd.Parameters.AddWithValue("@Matricula", camion.Matricula);
                cmd.Parameters.AddWithValue("@TipoCamion", camion.TipoCamion);
                cmd.Parameters.AddWithValue("@Modelo", camion.Modelo);
                cmd.Parameters.AddWithValue("@Marca", camion.Marca);
                cmd.Parameters.AddWithValue("@Capacidad", camion.Capacidad);
                cmd.Parameters.AddWithValue("@Kilometraje", camion.Kilometraje);
                cmd.Parameters.AddWithValue("@Disponibilidad", camion.Disponibilidad);
                cmd.Parameters.AddWithValue("@UrlFoto",
                    string.IsNullOrEmpty(camion.UrlFoto) ? (object)DBNull.Value : camion.UrlFoto);
                return cmd.ExecuteNonQuery() > 0;

            };
        }
    }
}
