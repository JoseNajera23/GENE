﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class Conexion
    {
        // Cadena de conexión centralizada
        private static string cadenaConexion = "Server=localhost;Database=GeNe;Integrated Security=true;";

        /// <summary>
        /// Obtiene una conexión abierta a la base de datos
        /// </summary>
        /// <returns>Objeto SqlConnection abierto</returns>
        public static SqlConnection ObtenerConexion()
        {
            SqlConnection conn = new SqlConnection(cadenaConexion);
            try
            {
                conn.Open();
                return conn;
            }
            catch (SqlException ex)
            {
                throw new Exception("Error al conectar con la base de datos: " + ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception("Error inesperado al conectar: " + ex.Message);
            }
        }

        /// <summary>
        /// Prueba si la conexión a la base de datos es exitosa
        /// </summary>
        /// <returns>True si la conexión es exitosa, False en caso contrario</returns>
        public static bool ProbarConexion()
        {
            try
            {
                using (SqlConnection conn = ObtenerConexion())
                {
                    return conn.State == ConnectionState.Open;
                }
            }
            catch
            {
                return false; // ← CORREGIDO: debe retornar false si hay error
            }
        }

        /// <summary>
        /// Obtiene la cadena de conexión actual
        /// </summary>
        /// <returns>Cadena de conexión</returns>
        public static string ObtenerCadenaConexion()
        {
            return cadenaConexion;
        }

        /// <summary>
        /// Permite cambiar la cadena de conexión en tiempo de ejecución
        /// </summary>
        /// <param name="nuevaCadena">Nueva cadena de conexión</param>
        public static void EstablecerCadenaConexion(string nuevaCadena)
        {
            if (string.IsNullOrWhiteSpace(nuevaCadena))
                throw new ArgumentException("La cadena de conexión no puede estar vacía");

            cadenaConexion = nuevaCadena;
        }

        /// <summary>
        /// Cierra una conexión de forma segura
        /// </summary>
        /// <param name="conn">Conexión a cerrar</param>
        public static void CerrarConexion(SqlConnection conn)
        {
            if (conn != null && conn.State == ConnectionState.Open)
            {
                try
                {
                    conn.Close();
                    conn.Dispose();
                }
                catch (Exception ex)
                {
                    throw new Exception("Error al cerrar la conexión: " + ex.Message);
                }
            }
        }

        /// <summary>
        /// Prueba la conexión y retorna un mensaje detallado
        /// </summary>
        /// <returns>Mensaje con el estado de la conexión</returns>
        public static string ProbarConexionDetallada()
        {
            try
            {
                using (SqlConnection conn = ObtenerConexion())
                {
                    if (conn.State == ConnectionState.Open)
                    {
                        return "Conexión exitosa a la base de datos 'GeNe' en " + conn.DataSource;
                    }
                    else
                    {
                        return "Error: La conexión no se pudo establecer";
                    }
                }
            }
            catch (SqlException ex)
            {
                return "Error SQL: " + ex.Message;
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
        }
    }
}