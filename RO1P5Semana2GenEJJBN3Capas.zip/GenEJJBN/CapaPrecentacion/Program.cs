﻿using System;
using System.Windows.Forms;

namespace CapaPrecentacion
{
    static class Program
    {
        [STAThread] //  MUY IMPORTANTE
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
          Application.Run(new FrmPrincipal());
        }
    }
}
