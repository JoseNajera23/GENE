﻿using CapaEntidades;
using CapaNegocios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace CapaPrecentacion
{
    public partial class FrmRutas : Form
    {
        private N_Ruta objNegocio = new N_Ruta();
        private int idRutaSeleccionado = 0;
        private bool esNuevo = false;

        public FrmRutas()
        {
            InitializeComponent();
            ConfigurarFormulario();
        }

        private void FrmRutas_Load(object sender, EventArgs e)
        {
            CargarFiltros();
            ListarRutas();
            BloquearControles();
        }

        private void ConfigurarFormulario()
        {
            // Configurar DataGridView
            ConfigurarDataGridView();

            // Configurar combos
            CargarFiltros();
        }

        #region Configuración Formulario y DataGridView

        private void ConfigurarDataGridView()
        {
            dgvRutas.AutoGenerateColumns = false;
            dgvRutas.Columns.Clear();

            dgvRutas.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "IdRutas",
                HeaderText = "ID Ruta",
                Width = 70
            });

            dgvRutas.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "IdChofer",
                HeaderText = "ID Chofer",
                Width = 80
            });

            dgvRutas.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "IdCamion",
                HeaderText = "ID Camión",
                Width = 80
            });

            dgvRutas.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Origen",
                HeaderText = "Origen",
                Width = 120
            });

            dgvRutas.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Destino",
                HeaderText = "Destino",
                Width = 120
            });

            dgvRutas.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "FechaSalida",
                HeaderText = "Fecha Salida",
                Width = 100,
                DefaultCellStyle = new DataGridViewCellStyle { Format = "dd/MM/yyyy" }
            });

            dgvRutas.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "FechaLlegada",
                HeaderText = "Fecha Llegada",
                Width = 100,
                DefaultCellStyle = new DataGridViewCellStyle { Format = "dd/MM/yyyy" }
            });

            dgvRutas.Columns.Add(new DataGridViewCheckBoxColumn
            {
                DataPropertyName = "ATiempo",
                HeaderText = "A Tiempo",
                Width = 80
            });

            dgvRutas.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Distancia",
                HeaderText = "Distancia (km)",
                Width = 100
            });
        }

        private void CargarFiltros()
        {
            cboFiltro.Items.Clear();
            cboFiltro.Items.Add("Todos");
            cboFiltro.Items.Add("Origen");
            cboFiltro.Items.Add("Destino");
            cboFiltro.Items.Add("A Tiempo");
            cboFiltro.Items.Add("Con Retraso");
            cboFiltro.SelectedIndex = 0;
        }

        #endregion

        #region CRUD y Control de Campos

        private void ListarRutas(string textoBusqueda = "")
        {
            try
            {
                List<E_Ruta> lista = objNegocio.ListarRutas();

                // Aplicar filtros
                if (cboFiltro.SelectedIndex == 3) // A Tiempo
                    lista = lista.Where(r => r.ATiempo == true).ToList();
                else if (cboFiltro.SelectedIndex == 4) // Con Retraso
                    lista = lista.Where(r => r.ATiempo == false).ToList();

                // Aplicar búsqueda por texto
                if (!string.IsNullOrWhiteSpace(textoBusqueda))
                {
                    string busqueda = textoBusqueda.ToUpper();

                    if (cboFiltro.SelectedIndex == 1) // Buscar por Origen
                        lista = lista.Where(r => r.Origen.ToUpper().Contains(busqueda)).ToList();
                    else if (cboFiltro.SelectedIndex == 2) // Buscar por Destino
                        lista = lista.Where(r => r.Destino.ToUpper().Contains(busqueda)).ToList();
                    else // Buscar en todos los campos
                        lista = lista.Where(r =>
                            r.Origen.ToUpper().Contains(busqueda) ||
                            r.Destino.ToUpper().Contains(busqueda) ||
                            r.IdChofer.ToString().Contains(busqueda) ||
                            r.IdCamion.ToString().Contains(busqueda)
                        ).ToList();
                }

                // Limpiar antes de asignar
                dgvRutas.DataSource = null;
                dgvRutas.DataSource = lista;

                if (lista.Count == 0)
                    MessageBox.Show("No hay rutas registradas", "Información",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al listar rutas: " + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BloquearControles()
        {
            txtOrigen.Enabled = false;
            txtDestino.Enabled = false;
            dtpFechaSalida.Enabled = false;
            dtpFechaEntrada.Enabled = false;
            chkATiempo.Enabled = false;
            nudDistancia.Enabled = false;
            nudIdChofer.Enabled = false;
            nudIdCamion.Enabled = false;

            btnGuardar.Enabled = false;
            btnCancelar.Enabled = false;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
        }

        private void DesbloquearControles()
        {
            txtOrigen.Enabled = true;
            txtDestino.Enabled = true;
            dtpFechaSalida.Enabled = true;
            dtpFechaEntrada.Enabled = true;
            chkATiempo.Enabled = true;
            nudDistancia.Enabled = true;
            nudIdChofer.Enabled = true;
            nudIdCamion.Enabled = true;

            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
        }

        private void LimpiarControles()
        {
            idRutaSeleccionado = 0;
            txtOrigen.Clear();
            txtDestino.Clear();
            dtpFechaSalida.Value = DateTime.Now;
            dtpFechaEntrada.Value = DateTime.Now;
            chkATiempo.Checked = false;

            // NumericUpDown Distancia
            nudDistancia.Minimum = 0;
            nudDistancia.Maximum = 10000;
            nudDistancia.Value = 0;

            // NumericUpDown IDs
            nudIdChofer.Minimum = 1;
            nudIdChofer.Maximum = 1000;
            nudIdChofer.Value = 1;

            nudIdCamion.Minimum = 1;
            nudIdCamion.Maximum = 1000;
            nudIdCamion.Value = 1;

            txtBuscar.Clear();
        }

        #endregion

        #region Botones

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            esNuevo = true;
            LimpiarControles();
            DesbloquearControles();
            txtOrigen.Focus();

            btnNuevo.Enabled = false;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                // Validaciones
                if (string.IsNullOrWhiteSpace(txtOrigen.Text))
                {
                    MessageBox.Show("El origen es obligatorio", "Validación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtOrigen.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtDestino.Text))
                {
                    MessageBox.Show("El destino es obligatorio", "Validación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtDestino.Focus();
                    return;
                }

                if (dtpFechaEntrada.Value < dtpFechaSalida.Value)
                {
                    MessageBox.Show("La fecha de llegada debe ser posterior a la fecha de salida",
                        "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dtpFechaEntrada.Focus();
                    return;
                }

                int idChofer = (int)nudIdChofer.Value;
                int idCamion = (int)nudIdCamion.Value;

                if (idChofer <= 0)
                {
                    MessageBox.Show("Debe seleccionar un ID de Chofer válido (mayor a 0)",
                        "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    nudIdChofer.Focus();
                    return;
                }

                if (idCamion <= 0)
                {
                    MessageBox.Show("Debe seleccionar un ID de Camión válido (mayor a 0)",
                        "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    nudIdCamion.Focus();
                    return;
                }

                // Crear objeto E_Ruta
                E_Ruta ruta = new E_Ruta
                {
                    IdRutas = idRutaSeleccionado,
                    IdChofer = idChofer,
                    IdCamion = idCamion,
                    Origen = txtOrigen.Text.Trim(),
                    Destino = txtDestino.Text.Trim(),
                    FechaSalida = dtpFechaSalida.Value,
                    FechaLlegada = dtpFechaEntrada.Value,
                    ATiempo = chkATiempo.Checked,
                    Distancia = (double)nudDistancia.Value,
                    FechaRegistro = DateTime.Now
                };

                // Guardar o actualizar
                string resultado = esNuevo ?
                    objNegocio.InsertarRuta(ruta) :
                    objNegocio.Actualizar(ruta);

                if (resultado == "Ok" || resultado == "OK")
                {
                    MessageBox.Show(
                        esNuevo ? "Ruta registrada exitosamente" : "Ruta actualizada exitosamente",
                        "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information
                    );

                    ListarRutas();
                    LimpiarControles();
                    BloquearControles();
                    btnNuevo.Enabled = true;
                    esNuevo = false;
                }
                else
                {
                    MessageBox.Show(resultado, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar: " + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (idRutaSeleccionado == 0)
            {
                MessageBox.Show("Debe seleccionar una ruta de la lista", "Advertencia",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            esNuevo = false;
            DesbloquearControles();

            btnNuevo.Enabled = false;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idRutaSeleccionado == 0)
            {
                MessageBox.Show("Debe seleccionar una ruta de la lista", "Advertencia",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirmacion = MessageBox.Show(
                "¿Está seguro de eliminar esta ruta?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (confirmacion == DialogResult.Yes)
            {
                string resultado = objNegocio.EliminarRuta(idRutaSeleccionado);
                if (resultado.ToUpper() == "OK")
                {
                    MessageBox.Show("Ruta eliminada exitosamente", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ListarRutas();
                    LimpiarControles();
                    BloquearControles();
                    btnNuevo.Enabled = true;
                }
                else
                {
                    MessageBox.Show(resultado, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            LimpiarControles();
            BloquearControles();
            btnNuevo.Enabled = true;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
            esNuevo = false;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string textoBusqueda = txtBuscar.Text.Trim();
            ListarRutas(textoBusqueda);
        }

        #endregion

        #region Eventos DataGridView y Controles

        private void dgvRutas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                try
                {
                    DataGridViewRow fila = dgvRutas.Rows[e.RowIndex];

                    idRutaSeleccionado = Convert.ToInt32(fila.Cells["IdRutas"].Value);
                    txtOrigen.Text = fila.Cells["Origen"].Value.ToString();
                    txtDestino.Text = fila.Cells["Destino"].Value.ToString();
                    dtpFechaSalida.Value = Convert.ToDateTime(fila.Cells["FechaSalida"].Value);
                    dtpFechaEntrada.Value = Convert.ToDateTime(fila.Cells["FechaLlegada"].Value);
                    chkATiempo.Checked = Convert.ToBoolean(fila.Cells["ATiempo"].Value);
                    nudDistancia.Value = Convert.ToDecimal(fila.Cells["Distancia"].Value);
                    nudIdChofer.Value = Convert.ToDecimal(fila.Cells["IdChofer"].Value);
                    nudIdCamion.Value = Convert.ToDecimal(fila.Cells["IdCamion"].Value);

                    btnModificar.Enabled = true;
                    btnEliminar.Enabled = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al seleccionar: " + ex.Message, "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            ListarRutas(txtBuscar.Text.Trim());
        }

        private void cboFiltro_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListarRutas(txtBuscar.Text.Trim());
        }

        #endregion

        #region Eventos vacíos del Designer

        private void dtpFechaSalida_ValueChanged(object sender, EventArgs e) { }
        private void dtpFechaEntrada_ValueChanged(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }

        #endregion
    }
}