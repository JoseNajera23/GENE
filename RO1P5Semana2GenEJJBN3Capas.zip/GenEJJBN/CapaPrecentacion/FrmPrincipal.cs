﻿using CapaNegocios;
using CapaPre;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPrecentacion
{
    public partial class FrmPrincipal : Form
    {
        private N_Camion objNegocio = new N_Camion();
        private int idChoferSeleccionado = 0;
        private bool esNuevo = false;
        public FrmPrincipal()
        {
            InitializeComponent();
            //nudIdChofer.AccessibleRole = AccessibleRole.None;
            //nudIdCamion.AccessibleRole = AccessibleRole.None;

        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            this.Text = "Sistema de Gestion de Camiones y Rutas - GenE";
        }

        private void mnuGestionarCamiones_Click(object sender,EventArgs e) {

            FrmCamiones frm = new FrmCamiones();
            frm.MdiParent = this;   
            frm.Show();
        } 
        private void mnuGestionarChoferes_Click(object sender,EventArgs e) {

            FrmChoferes frm = new FrmChoferes();
            frm.MdiParent = this;   
            frm.Show();
        }
        private void mnuGestionarRutas_Click(object sender,EventArgs e) {

            FrmRutas frm = new FrmRutas();
            frm.MdiParent = this;   
            frm.Show();
        }

        private void mnuSalir_Click(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show(
                "Estas Seguro que deseas salir del Sistema?",
                "Confirmar Salida",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
                );

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        private void camionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
               FrmChoferes frm = new FrmChoferes();
    frm.Show();
        }

        private void choferesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmChoferes frm = new FrmChoferes();
            frm.Show();

        }

        private void rutasToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
