﻿using CapaNegocios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using CapaEntidades;

namespace CapaPrecentacion
{
    public partial class FrmChoferes : Form
    {
        private N_Chofer objNegocio = new N_Chofer();
        private int idChoferSeleccionado = 0;
        private bool esNuevo = false;

        public FrmChoferes()
        {
            InitializeComponent();
        }

        private void FrmChofer_Load(object sender, EventArgs e)
        {
            BloquearControles();
            ConfigurarDataGridView();
            CargarFiltros(); // Esto ya carga los choferes automáticamente
        }

        #region Configuración Formulario y DataGridView

        private void ConfigurarDataGridView()
        {
            dgvChoferes.AutoGenerateColumns = false;
            dgvChoferes.Columns.Clear();

            dgvChoferes.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "IdChofer",
                HeaderText = "ID",
                Width = 50
            });

            dgvChoferes.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Nombre",
                HeaderText = "Nombre",
                Width = 100
            });

            dgvChoferes.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "ApPaterno",
                HeaderText = "Apellido Paterno",
                Width = 100
            });

            dgvChoferes.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "ApMaterno",
                HeaderText = "Apellido Materno",
                Width = 100
            });

            dgvChoferes.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Telefono",
                HeaderText = "Teléfono",
                Width = 100
            });

            dgvChoferes.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "FechaNacimiento",
                HeaderText = "Nacimiento",
                Width = 100,
                DefaultCellStyle = new DataGridViewCellStyle { Format = "dd/MM/yyyy" }
            });

            dgvChoferes.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Licencia",
                HeaderText = "Licencia",
                Width = 100
            });

            dgvChoferes.Columns.Add(new DataGridViewCheckBoxColumn
            {
                DataPropertyName = "Disponibilidad",
                HeaderText = "Disponible",
                Width = 80
            });
        }

        private void CargarFiltros()
        {
            // Desactivar temporalmente el evento para evitar múltiples llamadas
            cboFiltro.SelectedIndexChanged -= cboFiltro_SelectedIndexChanged;

            cboFiltro.Items.Clear();
            cboFiltro.Items.Add("Todos");
            cboFiltro.Items.Add("Disponibles");
            cboFiltro.Items.Add("No disponibles");
            cboFiltro.SelectedIndex = 0;

            // Reactivar el evento
            cboFiltro.SelectedIndexChanged += cboFiltro_SelectedIndexChanged;

            // Cargar choferes una sola vez
            ListarChoferes();
        }

        #endregion

        #region CRUD y Control de Controles

        private void ListarChoferes(string textoBusqueda = "")
        {
            try
            {
                List<E_Chofer> lista = objNegocio.ListarChoferes(null);

                if (cboFiltro.SelectedIndex == 1)
                    lista = lista.Where(c => c.Disponibilidad == true).ToList();
                else if (cboFiltro.SelectedIndex == 2)
                    lista = lista.Where(c => c.Disponibilidad == false).ToList();

                if (!string.IsNullOrWhiteSpace(textoBusqueda))
                {
                    string busqueda = textoBusqueda.ToUpper();
                    lista = lista.Where(c =>
                        c.Nombre.ToUpper().Contains(busqueda) ||
                        c.ApPaterno.ToUpper().Contains(busqueda) ||
                        c.ApMaterno.ToUpper().Contains(busqueda) ||
                        c.Telefono.Contains(busqueda) ||
                        c.Licencia.ToUpper().Contains(busqueda)
                    ).ToList();
                }

                dgvChoferes.DataSource = null;
                dgvChoferes.DataSource = lista;

                if (lista.Count == 0)
                    MessageBox.Show("No hay choferes registrados", "Información",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al listar choferes: " + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BloquearControles()
        {
            txtNombre.Enabled = false;
            txtApPaterno.Enabled = false;
            txtApMaterno.Enabled = false;
            txtTelefono.Enabled = false;
            dtFechaNacimiento.Enabled = false;
            txtLicencia.Enabled = false;
            txtUrlFoto.Enabled = false;
            chkDisponibilidad.Enabled = false;

            btnGuardar.Enabled = false;
            btnCancelar.Enabled = false;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
        }

        private void DesbloquearControles()
        {
            txtNombre.Enabled = true;
            txtApPaterno.Enabled = true;
            txtApMaterno.Enabled = true;
            txtTelefono.Enabled = true;
            dtFechaNacimiento.Enabled = true;
            txtLicencia.Enabled = true;
            txtUrlFoto.Enabled = true;
            chkDisponibilidad.Enabled = true;

            btnGuardar.Enabled = true;
            btnCancelar.Enabled = true;
        }

        private void LimpiarControles()
        {
            idChoferSeleccionado = 0;
            txtNombre.Clear();
            txtApPaterno.Clear();
            txtApMaterno.Clear();
            txtTelefono.Clear();
            dtFechaNacimiento.Value = DateTime.Now.AddYears(-25);
            txtLicencia.Clear();
            txtUrlFoto.Clear();
            chkDisponibilidad.Checked = true;
            txtBuscar.Clear();
        }

        #endregion

        #region Botones

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            esNuevo = true;
            LimpiarControles();
            DesbloquearControles();
            txtNombre.Focus();

            btnNuevo.Enabled = false;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            E_Chofer chofer = new E_Chofer
            {
                IdChofer = idChoferSeleccionado,
                Nombre = txtNombre.Text.Trim(),
                ApPaterno = txtApPaterno.Text.Trim(),
                ApMaterno = txtApMaterno.Text.Trim(),
                Telefono = txtTelefono.Text.Trim(),
                FechaNacimiento = dtFechaNacimiento.Value,
                Licencia = txtLicencia.Text.Trim(),
                UrlFoto = txtUrlFoto.Text.Trim(),
                Disponibilidad = chkDisponibilidad.Checked
            };

            string resultado = esNuevo
                ? objNegocio.InsertarChofer(chofer)
                : objNegocio.ActualizarChofer(chofer);

            if (resultado == "Ok")
            {
                MessageBox.Show("Operación realizada correctamente",
                    "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                ListarChoferes();
                LimpiarControles();
                BloquearControles();
                btnNuevo.Enabled = true;
                esNuevo = false;
            }
            else
            {
                MessageBox.Show(resultado,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (idChoferSeleccionado == 0)
            {
                MessageBox.Show("Debe seleccionar un chofer de la lista", "Advertencia",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            esNuevo = false;
            DesbloquearControles();

            btnNuevo.Enabled = false;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idChoferSeleccionado == 0)
            {
                MessageBox.Show("Debe seleccionar un chofer de la lista",
                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirmacion = MessageBox.Show(
                "¿Está seguro de eliminar este chofer?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (confirmacion == DialogResult.Yes)
            {
                string resultado = objNegocio.EliminarChofer(idChoferSeleccionado);

                if (resultado == "Ok")
                {
                    MessageBox.Show("Chofer eliminado correctamente",
                        "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    ListarChoferes();
                    LimpiarControles();
                    BloquearControles();
                    btnNuevo.Enabled = true;
                }
                else
                {
                    MessageBox.Show(resultado,
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            LimpiarControles();
            BloquearControles();
            btnNuevo.Enabled = true;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
            esNuevo = false;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string textoBusqueda = txtBuscar.Text.Trim();
            ListarChoferes(textoBusqueda);
        }

        #endregion

        #region Eventos DataGridView y Controles

        private void dgvChoferes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                try
                {
                    DataGridViewRow fila = dgvChoferes.Rows[e.RowIndex];

                    idChoferSeleccionado = Convert.ToInt32(fila.Cells["IdChofer"].Value);
                    txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
                    txtApPaterno.Text = fila.Cells["ApPaterno"].Value.ToString();
                    txtApMaterno.Text = fila.Cells["ApMaterno"].Value?.ToString() ?? "";
                    txtTelefono.Text = fila.Cells["Telefono"].Value.ToString();
                    dtFechaNacimiento.Value = Convert.ToDateTime(fila.Cells["FechaNacimiento"].Value);
                    txtLicencia.Text = fila.Cells["Licencia"].Value.ToString();
                    txtUrlFoto.Text = fila.Cells["UrlFoto"].Value?.ToString() ?? "";
                    chkDisponibilidad.Checked = Convert.ToBoolean(fila.Cells["Disponibilidad"].Value);

                    btnModificar.Enabled = true;
                    btnEliminar.Enabled = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al seleccionar: " + ex.Message, "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            ListarChoferes(txtBuscar.Text.Trim());
        }

        private void cboFiltro_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListarChoferes(txtBuscar.Text.Trim());
        }

        #endregion

        #region Métodos vacíos para eventos del Designer

        private void textLicencia_TextChanged(object sender, EventArgs e) { }
        private void dtFechaNacimiento_ValueChanged(object sender, EventArgs e) { }
        private void groupBox1_Enter(object sender, EventArgs e) { }
        private void groupBox6_Enter(object sender, EventArgs e) { }
        private void groupBox7_Enter(object sender, EventArgs e) { }
        private void txtNombre_TextChanged(object sender, EventArgs e) { }
        private void txtApPaterno_TextChanged(object sender, EventArgs e) { }

        #endregion
    }
}