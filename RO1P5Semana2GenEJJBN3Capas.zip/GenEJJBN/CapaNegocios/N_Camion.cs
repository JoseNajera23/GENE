﻿using CapaDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocios
{
    public class N_Camion
    {
        private D_Camion objDatos = new D_Camion();
        public List<E_Camion>ListarCamiones(bool? disponibilidad = null)
        {
            try
            {
                return objDatos.ListarCamiones(disponibilidad);
            }
            catch (Exception ex)
            {

                throw new Exception ("Error en Capa de Negocios: " + ex.Message);
            }
        }


        public string InsertaCamion(E_Camion camion) 
        {
            try
            {
                if (string.IsNullOrEmpty(camion.Matricula))
                    return "La Matricula es Obrigatoria";
                 if (string.IsNullOrEmpty(camion.TipoCamion))
                    return "El Tipo Camion es Obrigatorio";
                if (camion.Modelo < 1990 || camion.Modelo > DateTime.Now.Year + 1)
                    return "El Modelo del Camiondebe de estar entre 1900 y " + (DateTime.Now.Year + 1);
                if (string.IsNullOrEmpty(camion.Marca))
                    return "Marca del Camion es Obrigatorio";
                if (camion.Capacidad <=0)
                    return "La Capacidad de ser Mayor a 0"; 
                if (camion.Kilometraje <=0)
                    return "El Kilometraje no puede ser Negativo";
                //Verifica si matricula existe
                if (objDatos.ExisteMatricula(camion.Matricula)) 
                return "ya existe un camion con esa matricula";
                ///InsertaCamion 
                if (objDatos.InsertarCamion(camion))
                    return "Ok";
                else
                    return "Nose Puede Insertar Camion";

            }
            catch (Exception ex)
            {

               return "Error:" + ex.Message;
            }
        }

        public string ActualizarCamion(E_Camion camion)
        {
            try
            {
                //Validaciones similares al insertar
                if (string.IsNullOrEmpty(camion.Matricula))
                    return "La Matricula es Oblicatoria";
                if (camion.Modelo < 1990 || camion.Modelo > DateTime.Now.Year + 1)
                    return "El Modelo no es valido ";
                if (camion.Capacidad <= 0)
                    return "La Capacidad de ser Mayor a 0";
                if (objDatos.ActualizarCamion(camion))
                    return "OK";
                else
                    return "No se puede Actualizar Camion";



            }
            catch (Exception ex)
            {
                return "Error" + ex.Message;
            }
           
        }


        public string EliminarCamion(int idCamion)
        {
            try
            {
                if (objDatos.EliminarCamion(idCamion))
                    return "Ok";
                else
                    return "No se puede eliminar Camion";
            }
            catch (Exception ex)
            {

                return "Error" + ex.Message;
            }
        }

        public E_Camion ObtenerCamionPorId(int idCamion)
        {
            try
            {
                return objDatos.ObtenerCamionPorID(idCamion);
            }
            catch (Exception ex)
            {

                throw new Exception("Error:" + ex.Message);
            }
        }
    }
}
