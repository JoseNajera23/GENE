﻿using CapaDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;

namespace CapaNegocios
{
    public class N_Ruta
    {
        private D_Ruta objDatos = new D_Ruta();

        // Listar rutas
        public List<E_Ruta> ListarRutas()
        {
            try
            {
                return objDatos.ListaRutas();
            }
            catch (Exception ex)
            {
                throw new Exception("Error al listar rutas: " + ex.Message);
            }
        }

        // Insertar ruta
        public string InsertarRuta(E_Ruta ruta)
        {
            try
            {
                // Validaciones
                if (string.IsNullOrWhiteSpace(ruta.Origen))
                    return "El origen es obligatorio";

                if (string.IsNullOrWhiteSpace(ruta.Destino))
                    return "El destino es obligatorio";

                if (ruta.IdChofer <= 0)
                    return "Debe seleccionar un chofer válido";

                if (ruta.IdCamion <= 0)
                    return "Debe seleccionar un camión válido";

                if (ruta.FechaSalida >= ruta.FechaLlegada)
                    return "La fecha de llegada debe ser posterior a la de salida";

                if (ruta.Distancia <= 0)
                    return "La distancia debe ser mayor a 0";

                // Insertar en la base de datos
                bool resultado = objDatos.InsertarRuta(ruta);

                return resultado ? "Ok" : "No se pudo insertar la ruta";
            }
            catch (Exception ex)
            {
                return "Error al insertar: " + ex.Message;
            }
        }

        // Actualizar ruta
        public string Actualizar(E_Ruta ruta)
        {
            try
            {
                // Validaciones
                if (ruta.IdRutas <= 0)
                    return "ID de ruta inválido";

                if (string.IsNullOrWhiteSpace(ruta.Origen))
                    return "El origen es obligatorio";

                if (string.IsNullOrWhiteSpace(ruta.Destino))
                    return "El destino es obligatorio";

                if (ruta.FechaSalida >= ruta.FechaLlegada)
                    return "La fecha de llegada debe ser posterior a la de salida";

                if (ruta.Distancia <= 0)
                    return "La distancia debe ser mayor a 0";

                // Actualizar en la base de datos
                bool resultado = objDatos.ActualizarRuta(ruta);

                return resultado ? "Ok" : "No se pudo actualizar la ruta";
            }
            catch (Exception ex)
            {
                return "Error al actualizar: " + ex.Message;
            }
        }

        // Eliminar ruta
        public string EliminarRuta(int idRuta)
        {
            try
            {
                if (idRuta <= 0)
                    return "ID de ruta inválido";

                // Eliminar de la base de datos
                bool resultado = objDatos.EliminarRutas(idRuta);

                return resultado ? "Ok" : "No se pudo eliminar la ruta";
            }
            catch (Exception ex)
            {
                return "Error al eliminar: " + ex.Message;
            }
        }
    }
}