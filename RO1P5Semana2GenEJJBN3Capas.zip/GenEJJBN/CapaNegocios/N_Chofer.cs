﻿using CapaDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;

namespace CapaNegocios
{
    public class N_Chofer
    {
        private D_Chofer objDatos = new D_Chofer();

        // =========================
        // LISTAR
        // =========================
        public List<E_Chofer> ListarChoferes(bool? disponibilidad = null)
        {
            try
            {
                return objDatos.ListarChoferes(disponibilidad);
            }
            catch (Exception ex)
            {
                throw new Exception("Error en Capa de Negocios: " + ex.Message);
            }
        }

        // =========================
        // INSERTAR
        // =========================
        public string InsertarChofer(E_Chofer chofer)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(chofer.Nombre))
                    return "El nombre es obligatorio";

                if (string.IsNullOrWhiteSpace(chofer.ApPaterno))
                    return "El apellido paterno es obligatorio";

                if (string.IsNullOrWhiteSpace(chofer.Telefono))
                    return "El teléfono es obligatorio";

                if (chofer.FechaNacimiento > DateTime.Now.AddYears(-18))
                    return "El chofer debe ser mayor de edad";

                if (string.IsNullOrWhiteSpace(chofer.Licencia))
                    return "La licencia es obligatoria";

                // Verificar licencia duplicada
                if (objDatos.ExisteLicencia(chofer.Licencia))
                    return "Ya existe un chofer con esa licencia";

                // Insertar
                if (objDatos.InsertarChofer(chofer))
                    return "Ok";
                else
                    return "No se pudo insertar el chofer";
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
        }

        // =========================
        // ACTUALIZAR
        // =========================
        public string ActualizarChofer(E_Chofer chofer)
        {
            try
            {
                if (chofer.IdChofer <= 0)
                    return "ID de chofer inválido";

                if (string.IsNullOrWhiteSpace(chofer.Nombre))
                    return "El nombre es obligatorio";

                if (string.IsNullOrWhiteSpace(chofer.Licencia))
                    return "La licencia es obligatoria";

                // Verificar licencia duplicada excluyendo el mismo chofer
                if (objDatos.ExisteLicencia(chofer.Licencia, chofer.IdChofer))
                    return "La licencia ya está asignada a otro chofer";

                if (objDatos.ActualizarChofer(chofer))
                    return "Ok";
                else
                    return "No se pudo actualizar el chofer";
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
        }

        // =========================
        // ELIMINAR
        // =========================
        public string EliminarChofer(int idChofer)
        {
            try
            {
                if (idChofer <= 0)
                    return "ID inválido";

                if (objDatos.EliminarChoferes(idChofer))
                    return "Ok";
                else
                    return "No se pudo eliminar el chofer";
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
        }
    }
}
