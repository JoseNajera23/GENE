﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class E_Ruta
    {
        public int IdRutas { get; set; }
        public int IdChofer { get; set; }
        public int IdCamion { get; set; }
        public string Origen { get; set; }
        public string Destino { get; set; }
        public DateTime FechaSalida { get; set; }
        public DateTime FechaLlegada { get; set; }
        public bool ATiempo { get; set; }
        public double Distancia { get; set; }
        public DateTime FechaRegistro { get; set; }
    }
}
