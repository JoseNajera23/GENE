﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class E_Chofer
    {
        public int IdChofer { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string ApPaterno { get; set; } = string.Empty;
        public string ApMaterno { get; set; } = string.Empty;
        public string Telefono { get; set; } = string.Empty;
        public DateTime FechaNacimiento { get; set; }
        public string Licencia { get; set; } = string.Empty;
        public string UrlFoto { get; set; } = string.Empty;
        public bool Disponibilidad { get; set; } = true;

        // Propiedad calculada
        public string NombreCompleto => $"{Nombre} {ApPaterno} {ApMaterno}".Trim();

    }
}
