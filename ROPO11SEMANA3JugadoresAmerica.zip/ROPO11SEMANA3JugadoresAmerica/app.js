const express = require('express');
const bodyParser = require('body-parser');
const db = require('./database'); // Importamos la conexión SQLite (better-sqlite3)
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(cors());

//Mostrar ing Jugadores etc
app.use(express.static(__dirname));

// Ruta principal
app.get('/', (req, res) => {
  console.log('Acceso a la ruta principal /');
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Listar todos los jugadores
app.get('/jugadoresamerica', (req, res) => {
  console.log('Acceso a GET /jugadoresamerica');
  try {
    const rows = db.prepare('SELECT * FROM jugadoresamerica').all();
    res.json(rows);
  } catch (err) {
    console.error('Error al obtener videojuegos:', err.message);
    res.status(500).json({ error: 'Error al obtener videojuegos' });
  }
});

// Obtener un jugador por id
app.get('/jugadoresamerica/:id', (req, res) => {
  const id = parseInt(req.params.id);
  console.log(`Acceso a GET /jugadoresamerica/${id}`);
  try {
    const row = db.prepare('SELECT * FROM jugadoresamerica WHERE id = ?').get(id);
    if (row) {
      res.json(row);
    } else {
      res.status(404).json({ message: 'Videogame not found' });
    }
  } catch (err) {
    console.error('Error al obtener videojuego:', err.message);
    res.status(500).json({ error: 'Error al obtener videojuego' });
  }
});

// Insertar un nuevo Jugador Profecional
app.post('/jugadoresamerica', (req, res) => {
  console.log('Acceso a POST /jugadoresamerica');
  console.log('Datos recibidos del cliente:', req.body);

  const { name, description, photo, video } = req.body;

  if (!name || !description || !photo || !video) {
    console.error('Error: Datos incompletos');
    return res.status(400).json({ error: 'Todos los campos son obligatorios' });
  }

  try {
    const stmt = db.prepare(
      'INSERT INTO jugadoresamerica (name, description, photo, video) VALUES (?, ?, ?, ?)'
    );
    const info = stmt.run(name, description, photo, video);
    console.log('Jugador insertado correctamente con ID:', info.lastInsertRowid);
    res.status(201).json({ id: info.lastInsertRowid, ...req.body });
  } catch (err) {
    console.error('Error al insertar jugador:', err.message);
    res.status(500).json({ error: 'Error al insertar jugador' });
  }
});

// Actualizar un jugador existente
app.put('/jugadoresamerica/:id', (req, res) => {
  const id = parseInt(req.params.id);
  console.log(`Acceso a PUT /jugadoresamerica/${id}`);
  const { name, description, photo, video } = req.body;

  try {
    const stmt = db.prepare(
      'UPDATE jugadoresamerica SET name = ?, description = ?, photo = ?, video = ? WHERE id = ?'
    );
    const info = stmt.run(name, description, photo, video, id);

    if (info.changes === 0) {
      res.status(404).json({ message: 'jugadoresamerica not found' });
    } else {
      res.json({ id, name, description, photo, video });
    }
  } catch (err) {
    console.error('Error al actualizar jugador:', err.message);
    res.status(500).json({ error: 'Error al actualizar jugador' });
  }
});

// Eliminar un jugador
app.delete('/jugadoresamerica/:id', (req, res) => {
  const id = parseInt(req.params.id);
  console.log(`Acceso a DELETE /jugadoresamerica/${id}`);

  try {
    const stmt = db.prepare('DELETE FROM jugadoresamerica WHERE id = ?');
    const info = stmt.run(id);

    if (info.changes === 0) {
      res.status(404).json({ message: 'jugadoresamerica not found' });
    } else {
      res.status(204).send();
    }
  } catch (err) {
    console.error('Error al eliminar jugador:', err.message);
    res.status(500).json({ error: 'Error al eliminar jugador' });
  }
});

// Inicio del servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
